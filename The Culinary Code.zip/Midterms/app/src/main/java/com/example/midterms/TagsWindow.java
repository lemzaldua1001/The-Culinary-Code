package com.example.midterms;

import static androidx.core.content.PackageManagerCompat.LOG_TAG;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.example.midterms.databinding.ActivityRecipeWindowBinding;
import com.example.midterms.databinding.ActivityTagsWindowBinding;

import java.util.Objects;

public class TagsWindow extends AppCompatActivity {

    ActivityTagsWindowBinding binding;
    private static final String LOG_TAG =
            TagsWindow.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityTagsWindowBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        replaceFragment(new TagsFragment());
        Objects.requireNonNull(getSupportActionBar()).setBackgroundDrawable
                (new ColorDrawable(getResources().getColor(R.color.black)));

        binding.navigationView.setOnItemSelectedListener(item -> {

            switch (item.getItemId()){

                case R.id.recipes:
                    replaceFragment(new RecipesFragment());
                    onResume();
                    break;
                case R.id.favourites:
                    replaceFragment(new FavouritesFragment());
                    onResume();
                    break;
                case R.id.tags:
                    replaceFragment(new TagsFragment());
                    onResume();
                    break;



            }


            return true;
        });
    }

    private void replaceFragment(Fragment fragment){
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame_layout,fragment);
        fragmentTransaction.commit();
    }

    public void noContent(View view) {
        Toast toast = Toast.makeText(this, R.string.toast_message,
                Toast.LENGTH_SHORT);
        toast.show();
    }

    public void courses(View view) {
        Log.d(LOG_TAG, "Button Clicked!");
        Intent intent = new Intent(this, Courses.class);
        startActivity(intent);
    }
}