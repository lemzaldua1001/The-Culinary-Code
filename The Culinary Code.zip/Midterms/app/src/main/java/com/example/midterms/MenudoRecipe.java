package com.example.midterms;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MenudoRecipe extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menudo_recipe);
    }
}