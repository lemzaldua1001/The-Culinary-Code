package com.example.midterms;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.example.midterms.databinding.FragmentRecipesBinding;

public class MainActivity extends AppCompatActivity {;

    private static final String LOG_TAG =
            MainActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void openApp(View view) {
        Log.d(LOG_TAG, "I MISS YOU MA'AM");
        Intent intent = new Intent(this, MainMenu.class);
        startActivity(intent);
    }
}