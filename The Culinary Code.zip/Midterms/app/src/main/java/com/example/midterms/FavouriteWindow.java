package com.example.midterms;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;

import com.example.midterms.databinding.ActivityFavouriteWindowBinding;
import com.example.midterms.databinding.ActivityRecipeWindowBinding;

import java.util.Objects;

public class FavouriteWindow extends AppCompatActivity {

    ActivityFavouriteWindowBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityFavouriteWindowBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        replaceFragment(new FavouritesFragment());
        Objects.requireNonNull(getSupportActionBar()).setBackgroundDrawable
                (new ColorDrawable(getResources().getColor(R.color.black)));

        binding.navigationView.setOnItemSelectedListener(item -> {

            switch (item.getItemId()){

                case R.id.recipes:
                    replaceFragment(new RecipesFragment());
                    onResume();
                    break;
                case R.id.favourites:
                    replaceFragment(new FavouritesFragment());
                    onResume();
                    break;
                case R.id.tags:
                    replaceFragment(new TagsFragment());
                    onResume();
                    break;



            }


            return true;
        });
    }

    private void replaceFragment(Fragment fragment){
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame_layout,fragment);
        fragmentTransaction.commit();
    }
}