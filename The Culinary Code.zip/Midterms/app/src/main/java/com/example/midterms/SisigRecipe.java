package com.example.midterms;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SisigRecipe extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sisig_recipe);
    }
}