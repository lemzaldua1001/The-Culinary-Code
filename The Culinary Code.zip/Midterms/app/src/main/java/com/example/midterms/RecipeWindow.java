package com.example.midterms;

import static androidx.core.content.PackageManagerCompat.LOG_TAG;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.example.midterms.databinding.ActivityMainBinding;
import com.example.midterms.databinding.ActivityRecipeWindowBinding;
import com.example.midterms.databinding.FragmentRecipesBinding;

import java.util.Objects;

public class RecipeWindow extends AppCompatActivity {

    private static final String LOG_TAG =
            RecipeWindow.class.getSimpleName();

    ActivityRecipeWindowBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityRecipeWindowBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        replaceFragment(new RecipesFragment());
        Objects.requireNonNull(getSupportActionBar()).setBackgroundDrawable
                (new ColorDrawable(getResources().getColor(R.color.black)));

        binding.navigationView.setOnItemSelectedListener(item -> {

            switch (item.getItemId()){

                case R.id.recipes:
                    replaceFragment(new RecipesFragment());
                    onResume();
                    break;
                case R.id.favourites:
                    replaceFragment(new FavouritesFragment());
                    onResume();
                    break;
                case R.id.tags:
                    replaceFragment(new TagsFragment());
                    onResume();
                    break;



            }


            return true;
        });
    }

    private void replaceFragment(Fragment fragment){
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame_layout,fragment);
        fragmentTransaction.commit();
    }

    public void menudoView(View view) {
        Log.d(LOG_TAG, "Button Clicked!");
        Intent intent = new Intent(this, MenudoRecipe.class);
        startActivity(intent);
    }

    public void bulaloView(View view) {
        Log.d(LOG_TAG, "Button Clicked!");
        Intent intent = new Intent(this, BulaloRecipe.class);
        startActivity(intent);
    }

    public void sisigView(View view) {
        Log.d(LOG_TAG, "Button Clicked!");
        Intent intent = new Intent(this, SisigRecipe.class);
        startActivity(intent);
    }

    public void tinolaView(View view) {
        Log.d(LOG_TAG, "Button Clicked!");
        Intent intent = new Intent(this, TinolaRecipe.class);
        startActivity(intent);
    }

    public void sinigangView(View view) {
        Log.d(LOG_TAG, "Button Clicked!");
        Intent intent = new Intent(this, SinigangRecipe.class);
        startActivity(intent);
    }

    public void adoboView(View view) {
        Log.d(LOG_TAG, "Button Clicked!");
        Intent intent = new Intent(this, AdoboRecipe.class);
        startActivity(intent);
    }

    public void chopsueyView(View view) {
        Log.d(LOG_TAG, "Button Clicked!");
        Intent intent = new Intent(this, ChopsueyRecipe.class);
        startActivity(intent);
    }
}