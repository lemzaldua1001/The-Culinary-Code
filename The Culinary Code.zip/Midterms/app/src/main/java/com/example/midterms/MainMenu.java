package com.example.midterms;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.fragment.app.FragmentTransitionImpl;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.example.midterms.databinding.ActivityMainMenuBinding;

import java.util.Objects;

public class MainMenu extends AppCompatActivity {

    private ActivityMainMenuBinding binding;

    private static final String LOG_TAG =
            MainMenu.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainMenuBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        Objects.requireNonNull(getSupportActionBar()).setBackgroundDrawable
                (new ColorDrawable(getResources().getColor(R.color.black)));
    }

    public void openRecipeWindow(View view) {
        Log.d(LOG_TAG, "I MISS YOU MUCH");
        Intent intent = new Intent(this, RecipeWindow.class);
        startActivity(intent);
    }
    public void openFavouriteWindow(View view) {
        Log.d(LOG_TAG, "I MISS YOU MUCH");
        Intent intent = new Intent(this, FavouriteWindow.class);
        startActivity(intent);
    }

    public void openTagsWindow(View view) {
        Log.d(LOG_TAG, "I MISS YOU MUCH");
        Intent intent = new Intent(this, TagsWindow.class);
        startActivity(intent);
    }

    public void addRecipe(View view) {
        Log.d(LOG_TAG, "Button Clicked!");
        Intent intent = new Intent(this, create_recipe.class);
        startActivity(intent);
    }

    public void openGroceryWindow(View view) {
        Log.d(LOG_TAG, "Button Clicked!");
        Intent intent = new Intent(this, GroceryLists.class);
        startActivity(intent);
    }
}